Thank for downloading KIDSPACE.



NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated. 

Paypal account for donation : https://www.paypal.me/monocotype

Thanks,


Monocotype Studio